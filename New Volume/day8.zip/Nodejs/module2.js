var mod = require("./calc")
console.log("Add: "+ mod.add(30,20)+" Sum: "+mod.sum(10,20)+ " Substract: "+mod.substract(10,20)+ " Divide: "+
mod.divide(20,2)+ " Multiply: "+mod.multiply(3,4)+ " Min: "+mod.min(1,3,2)+ " Max: "+
mod.max(12,3,45)+ " Square: "+mod.square(5)
)