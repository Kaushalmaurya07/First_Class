var mod = require("./m")

console.log(mod.studname,mod.age)

mod.greet()
mod.greetInSpanish()

console.log("Age is "+mod.add(11,33))