var mod = require("./module1")

console.log(mod.greet())