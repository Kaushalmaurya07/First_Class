exports.studname = 'Sahil Khatkar'
exports.age = 24

exports.greet = () =>{
    console.log("Hello "+ this.studname)
}

exports.greetInSpanish = () =>{
    console.log("Hola "+ this.studname)
}

exports.add = (a,b) =>a+b 
