public class JavaQuestion2 {
	public static void main(String[] args) {
	    String sentence = "This is a sample sentence";
	    System.out.println("Sentence before opposite order:  "+sentence);
	    String reversedSentence = reverseWords(sentence);
	    System.out.println("Sentence After opposite order:  "+reversedSentence);
	  }

	  public static String reverseWords(String sentence) {
	    String[] words = sentence.split(" ");
	    StringBuilder reversedWords = new StringBuilder();
	    for (String word : words) {
	      reversedWords.append(new StringBuilder(word).reverse());
	      reversedWords.append(" ");
	    }
	    return reversedWords.toString().trim();
	  }
}
