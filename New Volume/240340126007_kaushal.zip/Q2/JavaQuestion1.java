import java.util.Scanner;

public class JavaQuestion1 {
	
	public static void main(String[] args) {
		
		    String sentence;
		    System.out.println("Enter the Sentence:");
		    Scanner sc=new Scanner(System.in);
		    sentence=sc.nextLine();
		    String[] words = sentence.split(" ");
		    for (String word : words) {
		      if (word.length() % 2 == 0) {
		        System.out.println(word);
		      }
		    }
		  
}
}
